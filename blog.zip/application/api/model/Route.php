<?php


namespace app\api\model;


use think\Model;

class Route extends Model
{
    public $autoWriteTimestamp = 'datetime';
    protected $pk = 'id';

}