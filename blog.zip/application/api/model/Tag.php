<?php


namespace app\api\model;

use think\Model;

class Tag extends Model
{
    public $autoWriteTimestamp = 'datetime';

}